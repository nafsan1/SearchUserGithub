package com.github.nafsan.searchuser.viewmodel

import com.github.nafsan.searchuser.model.User


data class MainViewState (
    var loading: Boolean = false,
    var error: Exception? = null,
    var data: MutableList<User>? = null
)