package com.github.nafsan.searchuser.repository

import android.util.Log
import com.github.nafsan.searchuser.datastore.UserSetDataStore
import com.github.nafsan.searchuser.model.User


class UserSetRepository private constructor() : BaseRepository<UserSetDataStore>() {

    suspend fun getUser(
        q: String,
        page: Int,
        perPage: Int
    ): MutableList<User>? {
        var sameTex = ""

        if (q.equals(sameTex)){
            sameTex = q
            val cache = localDataStore?.getUser(q, page, perPage)
            if (cache != null) return cache
            val response = remoteDataStore?.getUser(q, page, perPage)
            localDataStore?.addAll(response)
            return response
        }else{

            val response = remoteDataStore?.getUser(q, page, perPage)
            localDataStore?.addAll(response)

            sameTex = q

            return response
        }


    }

    companion object{
        val instance by lazy { UserSetRepository() }
    }
}