package com.github.nafsan.searchuser.viewmodel


import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.github.nafsan.searchuser.model.User
import com.github.nafsan.searchuser.repository.UserSetRepository
import kotlinx.coroutines.launch
import java.lang.Exception

class MainvViewModel(private val userSet: UserSetRepository):ViewModel() {

    private val mViewState = MutableLiveData<MainViewState>().apply{
        value = MainViewState(loading = false)
    }
    val viewState : LiveData<MainViewState>
    get() = mViewState


    fun getSets(q:String,page:Int,perPage:Int) = viewModelScope.launch {
        try {
            Log.e("MainViewModel","TES")
            val data = userSet.getUser(q,page,perPage)
            mViewState.value = mViewState.value?.copy(loading = false, error = null, data = data)
            Log.e("MainViewModel", data!!.get(1).login)
        }catch (ex:Exception){
            mViewState.value = mViewState.value?.copy(loading = false, error = ex, data = null)
        }
    }
}