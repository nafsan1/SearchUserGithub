package com.github.nafsan.searchuser.datastore

import com.github.nafsan.searchuser.model.User

class UserSetLocalDataStore :
    UserSetDataStore {
    private var caches = mutableListOf<User>()

    override suspend fun getUser( q: String,
                                  page: Int,
                                  perPage: Int): MutableList<User>? =
        if (caches.isNotEmpty()) caches else null


    override suspend fun addAll(sets: MutableList<User>?) {
        sets?.let { caches = it }
    }


}